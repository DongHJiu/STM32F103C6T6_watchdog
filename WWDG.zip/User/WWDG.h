#ifndef __WWDG_H
#define __WWDG_H

void WWDGInit(u8 tly,u8 tey,u32 data);

#endif
