#include "stm32f10x.h"                  // Device header
#include "WWDG.h"
#include "LED.h"
#include "Delay.h"


/**
  *分频之后的计数器时钟公式为：CK_CNT=PCLK1/4092/(2^WDGTB)
  *PCLK1是APB1总线的时钟频率(36MHZ)，4092是固定值，WDGTB是预分频系数，(2^WDGTB)是预分频值
	*下面的值代入公式则是：CK_CNT=36000000/4092/8≈1100HZ  
	*                      计数器计一个数的时间≈0.0009秒  
	*                      看门狗喂一次狗的时间为0.0567秒
**/
int main(void){
	WWDGInit(0x7F,0x5F,WWDG_Prescaler_8);
	LED_Init();
	LED_Data(1);
	while(1){
		LED_Data(1);
		Delay_ms(1000);
		LED_Data(0);
		Delay_ms(1000);
	}
}
