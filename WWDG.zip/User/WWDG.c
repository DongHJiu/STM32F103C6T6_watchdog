#include "stm32f10x.h"                  // Device header

u8 WWDG_CNT=0x7F;                       //此值是看门狗计数器的最大值(计数器的值是7位有效值)


/**
  * @brief  WWDG初始化设置
  * @param  tly  @计数器的值(看门狗总共要执行几个周期)
	* @param  tey  @窗口的上限值(到达这个值才可以进行喂狗)
	*	@param	data @预分频值
  * @retval 无  
  */
void WWDGInit(u8 tly,u8 tey,u32 data){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG,ENABLE);
	
	WWDG_CNT=tly&WWDG_CNT;
	WWDG_SetPrescaler(data);              //设置分频值
	WWDG_SetWindowValue(tey);             //设置窗口的上限值
	//WWDG_SetCounter(WWDG_CNT);                  //设置计数值
	WWDG_Enable(WWDG_CNT);                //开启看门狗  
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitTypeDef NVICWWDG;
	NVICWWDG.NVIC_IRQChannel=WWDG_IRQn;
	NVICWWDG.NVIC_IRQChannelCmd=ENABLE;
	NVICWWDG.NVIC_IRQChannelPreemptionPriority=2;
	NVICWWDG.NVIC_IRQChannelSubPriority=2;
	NVIC_Init(&NVICWWDG);
	
	WWDG_ClearFlag();                     //清除提前唤醒中断标志位
	WWDG_EnableIT();                      //开启提前唤醒中断
}


void WWDG_IRQHandler(void){

	WWDG_SetCounter(WWDG_CNT);     //此函数喂狗
	
	WWDG_ClearFlag();      //清除提前唤醒中断标志位
	
}
