#include "stm32f10x.h"                  // Device header
#include "LED.h"
#include "Key.h"
#include "IWDG.h"
#include "Delay.h"


/**
	*独立看门狗的溢出时间设置公式为：Tout=((4×2^prer) ×rlr)/(30~60)Khz
	*Tout为溢出时间值（单位为1秒）；
	*prer为计数器时钟的预分频系数
	*(4*2^prer)为计数器时钟的预分频值（IWDG_PR 值）；
	*rlr为看门狗的重装载值（IWDG_RLR 的值）；这个值就是看门狗运行了几个周期后重装(也就是计数器的值,最大是15位有效)
	*(30Khz到60Khz是不确定的)这个范围的为独立看门狗专门的内部低速时钟驱动；
**/	
int main(void){
	LED_Init();
	Key_Init();
	LED_Data(1);
	Delay_ms(1000);
	IWDGInit(4,950);

	while(1){
		LED_Data(0);
		if(KeyOnce()==1){
			IWDG_ReloadCounter();
		}
	}
}
