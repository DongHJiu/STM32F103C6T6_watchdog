#include "stm32f10x.h"                  // Device header


/**
  * @brief  IWDG初始化
  * @param  ttl  @设置预分频系数
	* @param  data @设置重装载值
  * @retval 无  
  */
void IWDGInit(u8 ttl,u16 data){
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);     //是否取消写入保护(这里设置取消)
	IWDG_SetPrescaler(ttl);       //设置预分频系数(这里设置从外部传入)
	IWDG_SetReload(data);         //设重装载值(这里设置从外部传入)
	IWDG_ReloadCounter();         //(这个函数是给看门狗喂食的) (这里只是加载一下寄存器的值)
	IWDG_Enable();                //使能看门狗
}
