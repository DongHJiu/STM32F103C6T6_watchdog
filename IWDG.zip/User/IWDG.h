#ifndef __IWDG_H
#define __IWDG_H

void IWDGInit(u8 ttl,u16 data);


#endif
